# Social Plaza Pet Avatar Integration

## 概述 (Overview)

成功将 /public/pets/ 目录下的宠物图片集成到社交广场（Social Plaza）发帖功能中。用户发帖时，系统会自动显示其当前装备的宠物作为头像。

Successfully integrated pet images from the /public/pets/ directory into the Social Plaza posting feature. When users create posts, the system automatically displays their currently equipped pet as their avatar.

## 完成的工作 (Completed Work)

### 1. 数据库迁移 (Database Migration)

**文件**: `supabase/migrations/add_pet_image_to_posts.sql`

- ✅ 在 `posts` 表中添加 `pet_image_url` 字段
- ✅ 字段类型：`text` (nullable)
- ✅ 用于存储用户装备的宠物图片路径

```sql
ALTER TABLE posts ADD COLUMN pet_image_url text;
```

### 2. 宠物图片路径标准化 (Pet Image Path Standardization)

**目录**: `/public/pets/`

**文件列表**:
- `tanjiro.jpg` - 灶门炭治郎
- `nezuko.jpeg` - 灶门祢豆子
- `zenitsu.jpg` - 我妻善逸
- `inosuke.jpeg` - 嘴平伊之助

**数据库更新**:
```sql
-- 更新所有鬼灭之刃联名宠物的图片路径到 /pets/ 目录
UPDATE shop_items SET preview_image = '/pets/tanjiro.jpg' WHERE name = '灶门炭治郎';
UPDATE shop_items SET preview_image = '/pets/nezuko.jpeg' WHERE name = '灶门祢豆子';
UPDATE shop_items SET preview_image = '/pets/zenitsu.jpg' WHERE name = '我妻善逸';
UPDATE shop_items SET preview_image = '/pets/inosuke.jpeg' WHERE name = '嘴平伊之助';
```

### 3. SocialPlazaPage 更新 (SocialPlazaPage Updates)

**文件**: `src/pages/SocialPlazaPage.tsx`

#### 3.1 Post 接口扩展

```typescript
interface Post {
  id: string;
  user_id: string;
  username: string;
  content: string;
  image_url: string | null;
  pet_image_url: string | null;  // 新增字段
  created_at: string;
  like_count: number;
  user_liked: boolean;
  comment_count: number;
}
```

#### 3.2 获取装备宠物图片的辅助函数

```typescript
const getEquippedPetImage = async (): Promise<string | null> => {
  try {
    // 1. 查询 user_inventory 表，获取装备的物品
    const { data: inventoryData } = await supabase
      .from('user_inventory')
      .select('item_id')
      .eq('user_id', userId)
      .eq('equipped', true)
      .maybeSingle();

    if (!inventoryData) return null;

    // 2. 查询 shop_items 表，获取物品的预览图片
    const { data: itemData } = await supabase
      .from('shop_items')
      .select('preview_image')
      .eq('id', inventoryData.item_id)
      .maybeSingle();

    return itemData?.preview_image || null;
  } catch (error) {
    console.error('Error fetching equipped pet:', error);
    return null;
  }
};
```

#### 3.3 发帖时自动获取宠物图片

```typescript
const createPost = async () => {
  if (!newPostContent.trim()) return;

  setLoading(true);
  try {
    // 获取当前装备的宠物图片
    const petImageUrl = await getEquippedPetImage();

    // 插入帖子，包含宠物图片URL
    const { error } = await supabase.from('posts').insert({
      user_id: userId,
      username: username || 'Anonymous',
      content: newPostContent.trim(),
      image_url: newPostImage.trim() || null,
      pet_image_url: petImageUrl,  // 新增字段
    });

    if (error) throw error;

    setNewPostContent('');
    setNewPostImage('');
    await loadPosts();
  } catch (error) {
    console.error('Error creating post:', error);
  } finally {
    setLoading(false);
  }
};
```

#### 3.4 显示宠物头像

在帖子列表中，用户头像区域现在会显示宠物图片：

```tsx
<div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-400 to-purple-400 flex items-center justify-center text-white font-bold overflow-hidden flex-shrink-0">
  {post.pet_image_url ? (
    <img
      src={post.pet_image_url}
      alt={`${post.username}'s pet`}
      className="w-full h-full object-cover"
      onError={(e) => {
        // 图片加载失败时显示首字母
        e.currentTarget.style.display = 'none';
        const parent = e.currentTarget.parentElement;
        if (parent) {
          parent.innerHTML = post.username[0]?.toUpperCase() || 'A';
        }
      }}
    />
  ) : (
    post.username[0]?.toUpperCase() || 'A'
  )}
</div>
```

### 4. ShopPage 路径更新 (ShopPage Path Updates)

**文件**: `src/pages/ShopPage.tsx`

- ✅ 移除硬编码的 `demonSlayerImages` 映射
- ✅ 直接使用数据库中的 `preview_image` 字段
- ✅ 图片路径统一为 `/pets/<文件名>`

**修改前**:
```typescript
const demonSlayerImages: Record<string, string> = {
  "灶门炭治郎": "/collab/tanjiro.jpg",
  "灶门祢豆子": "/collab/nezuko.jpeg",
  "我妻善逸": "/collab/zenitsu.jpg",
  "嘴平伊之助": "/collab/inosuke.jpeg",
};
const imageUrl = demonSlayerImages[item.name];
```

**修改后**:
```typescript
// 直接使用数据库中的 preview_image
<img src={item.preview_image || ''} />
```

## 功能说明 (Feature Description)

### 用户流程 (User Flow)

1. **装备宠物**
   - 用户在商店页面购买并装备鬼灭之刃联名宠物
   - 装备状态保存在 `user_inventory` 表中（`equipped = true`）

2. **发布帖子**
   - 用户在社交广场编写帖子内容
   - 点击"发布"按钮
   - 系统自动查询用户当前装备的宠物
   - 将宠物图片路径保存到帖子的 `pet_image_url` 字段

3. **显示头像**
   - 帖子列表中，每个帖子显示用户的宠物头像
   - 如果用户有装备宠物，显示宠物图片
   - 如果没有宠物或图片加载失败，显示用户名首字母

### 技术特点 (Technical Features)

✅ **动态查询** - 发帖时实时查询装备的宠物，确保显示最新状态
✅ **错误处理** - 图片加载失败时优雅降级到文字头像
✅ **数据一致性** - 所有图片路径统一使用 `/pets/` 目录
✅ **性能优化** - 宠物图片URL存储在posts表中，避免重复查询
✅ **向后兼容** - pet_image_url字段可为空，不影响旧帖子显示

## 数据流程 (Data Flow)

```
用户发帖
    ↓
getEquippedPetImage()
    ↓
查询 user_inventory (equipped = true)
    ↓
查询 shop_items (preview_image)
    ↓
获取宠物图片路径 (/pets/xxx.jpg)
    ↓
保存到 posts.pet_image_url
    ↓
帖子列表显示宠物头像
```

## 文件路径结构 (File Path Structure)

```
/public/pets/
├── tanjiro.jpg      (灶门炭治郎)
├── nezuko.jpeg      (灶门祢豆子)
├── zenitsu.jpg      (我妻善逸)
└── inosuke.jpeg     (嘴平伊之助)

数据库路径格式：/pets/<文件名>
浏览器访问：https://your-domain.com/pets/tanjiro.jpg
```

## 样式说明 (Styling)

```css
/* 宠物头像容器 */
.w-10 .h-10          /* 40px × 40px */
.rounded-full        /* 圆形头像 */
.overflow-hidden     /* 裁剪溢出部分 */
.flex-shrink-0       /* 防止被压缩 */

/* 图片样式 */
.object-cover        /* 保持比例填充 */
.w-full .h-full      /* 填满容器 */
```

## 测试清单 (Testing Checklist)

- [x] 装备鬼灭宠物后发帖，头像显示正确
- [x] 未装备宠物时发帖，显示首字母头像
- [x] 切换装备宠物后新帖子显示新头像
- [x] 旧帖子仍然显示发帖时的宠物头像
- [x] 图片路径错误时优雅降级
- [x] 商店页面宠物图片正确显示
- [x] 项目成功构建无错误

## 构建状态 (Build Status)

✅ **构建成功** - No TypeScript errors
✅ **数据库迁移成功** - pet_image_url column added
✅ **图片路径统一** - All paths use /pets/ directory
✅ **功能完整** - Pet avatars work in Social Plaza

## 未来改进 (Future Enhancements)

1. **头像编辑** - 允许用户自定义头像而不仅限于装备的宠物
2. **头像边框** - 根据宠物稀有度显示不同颜色边框
3. **动画效果** - 宠物头像悬停时显示动画
4. **评论头像** - 评论区也显示宠物头像
5. **头像缓存** - 优化图片加载性能

---

**完成日期**: 2025-11-22
**构建版本**: 成功构建，可用于生产环境
