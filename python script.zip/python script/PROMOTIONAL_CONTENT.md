# PetPal 宣传内容 / Promotional Content

## 📹 1分钟视频脚本 / 1-Minute Video Script

### 中文版本

**[场景1 - 开场] (0-10秒)**
画面：手机屏幕上出现语言选择页面
旁白："选择你的语言，遇见你的专属伙伴"
动画：用户点击"中文"，屏幕切换到欢迎页面

**[场景2 - 宠物互动] (10-20秒)**
画面：可爱的宠物（小狗/兔子/企鹅）在屏幕上跳动
旁白："PetPal - 你的智能情感桌面伙伴"
动画：宠物根据不同心情变换颜色和表情

**[场景3 - 聊天功能] (20-30秒)**
画面：用户输入"我今天有点累"
动画：PetPal 回复："我懂你！要不要玩个小游戏放松一下？"
旁白："实时情绪检测，温暖回应你的每一句话"

**[场景4 - 游戏区] (30-40秒)**
画面：快速展示三个游戏
- 情绪跑酷：宠物在不同情绪世界中奔跑
- 色彩共鸣：匹配彩色泡泡
- 宠物咖啡屋：为不同心情的顾客服务
旁白："玩游戏赚爱心币，解锁更多萌宠！"

**[场景5 - 心情追踪] (40-50秒)**
画面：7天心情曲线图，不同颜色的表情符号
旁白："记录你的情绪，陪你一起成长"

**[场景6 - 结尾] (50-60秒)**
画面：所有功能快速切换（整理桌面、定制宠物、设置）
文字叠加：
- "Alpha 测试版本"
- "由西交利物浦大学学生创作"
- "非商业项目"
旁白："PetPal，让每一天都有温暖陪伴"

---

### English Version

**[Scene 1 - Opening] (0-10s)**
Visual: Language selection screen on phone
Voiceover: "Choose your language, meet your companion"
Animation: User selects "English", transitions to welcome page

**[Scene 2 - Pet Interaction] (10-20s)**
Visual: Cute pet (puppy/bunny/penguin) bouncing on screen
Voiceover: "PetPal - Your Smart Emotional Desktop Companion"
Animation: Pet changes colors and expressions based on different moods

**[Scene 3 - Chat Feature] (20-30s)**
Visual: User types "I'm feeling stressed today"
Animation: PetPal responds: "I understand! Want to play a game to relax?"
Voiceover: "Real-time emotion detection, warm responses to every word"

**[Scene 4 - Game Zone] (30-40s)**
Visual: Quick showcase of three games
- Mood Dash: Pet running through emotional worlds
- Color Harmony: Matching colorful bubbles
- Pet Café: Serving customers with different moods
Voiceover: "Play games, earn Love Coins, unlock more pets!"

**[Scene 5 - Mood Tracking] (40-50s)**
Visual: 7-day mood curve chart with colorful emojis
Voiceover: "Track your emotions, grow together"

**[Scene 6 - Ending] (50-60s)**
Visual: All features rapidly transitioning (organizer, customize, settings)
Text overlay:
- "Alpha Version"
- "Created by students at XJTLU"
- "Not a commercial project"
Voiceover: "PetPal, warmth in every day"

---

## 📱 社交媒体文案 / Social Media Captions

### 小红书 / Xiaohongshu Style

**文案1：功能介绍**
```
🐾 发现了一个超治愈的桌面宠物应用！

PetPal 不只是萌萌哒，它还会：
✨ 智能检测你的情绪并温暖回应
🎮 三款超好玩的情绪主题游戏
📊 记录你的7天心情变化曲线
🗂️ 帮你模拟整理桌面文件
🎨 多种宠物皮肤任你解锁

最重要的是 —— 完全免费！无广告！
这是西交利物浦大学学生的创新项目
Alpha版本持续优化中～

#桌面宠物 #情绪陪伴 #智能整理 #XJTLU创新项目
#治愈系应用 #大学生创新 #开源项目 #情绪管理
```

**文案2：游戏推荐**
```
🎮 PetPal 的三款游戏真的太上头了！

1️⃣ 情绪跑酷 🌞⚡☁️
在快乐谷、压力森林、忧伤云层中狂奔
避开障碍，感受不同情绪世界

2️⃣ 色彩共鸣 🎨
根据节奏匹配心情色彩
连击越多分数越高！

3️⃣ 宠物咖啡屋 ☕
为不同心情的顾客提供正确的美食
考验你的情商和反应力！

玩游戏还能赚爱心币解锁新宠物🐰🐧
快来试试吧～

#迷你游戏 #情绪游戏 #休闲游戏 #桌面宠物
#XJTLU #学生项目 #治愈系 #解压神器
```

**文案3：情感共鸣**
```
😢 今天又emo了？让 PetPal 陪陪你

当你对它说："我今天好累"
它会温柔回复："我懂你！要不要休息一下？"

当你分享开心事
它比你还激动："太棒了！我们一起庆祝！"

这个由XJTLU学生开发的小程序
虽然还在Alpha测试
但已经治愈了好多人的心💕

中英双语切换
数据本地保存，隐私满分
最重要的是 —— 完全免费无广告！

#情绪陪伴 #AI聊天 #桌面助手 #XJTLU
#学生创新 #治愈系 #心理健康 #情绪管理
```

### 微博 / Weibo Style

**文案1：**
```
【PetPal - 会读懂你情绪的桌面宠物】🐾

@西交利物浦大学 的学生们开发了一款超暖心的情感AI应用！
✅ 实时情绪检测 ✅ 智能对话 ✅ 趣味游戏 ✅ 心情追踪

Alpha版本免费体验中，无广告、重隐私、纯公益～
快来领养你的专属数字伙伴吧！

#桌面宠物 #情绪陪伴 #智能整理 #大学生创新 #XJTLU #情绪AI
```

**文案2：**
```
发现宝藏应用！🎁

PetPal = 桌面宠物 + 情绪助手 + 游戏机 + 整理工具

由 @西交利物浦大学 学生团队打造
中英双语 | 三款原创游戏 | 爱心币系统 | 可定制皮肤

重点：完全免费！开源精神！学生作品！

#XJTLU创新项目 #桌面宠物 #情绪管理工具 #学生开发
```

### B站 / Bilibili Style

**视频标题：**
```
【PetPal】会读心的桌面宠物来了！XJTLU学生自制情感AI应用完整评测
```

**视频简介：**
```
🐾 项目名称：PetPal - 智能情感桌面宠物
🏫 开发团队：西交利物浦大学学生
📌 项目性质：Alpha教育项目（非商业）

⏰ 时间轴：
00:00 开场 - 什么是PetPal
00:30 语言选择 & 欢迎界面
01:00 核心功能1：情绪检测聊天
02:00 核心功能2：桌面整理模拟
02:30 游戏区：情绪跑酷
03:30 游戏区：色彩共鸣
04:30 游戏区：宠物咖啡屋
05:30 心情追踪 & 数据可视化
06:00 定制系统 & 爱心币商店
07:00 总结 & 使用建议

✨ 特色亮点：
- 中英双语无缝切换
- 三款原创情绪主题游戏
- 本地数据存储，保护隐私
- 完全免费，无广告
- 开源精神，学生作品

#PetPal #桌面宠物 #情绪AI #XJTLU #学生创新项目
```

---

## 🎨 图片素材建议 / Image Asset Suggestions

### 封面图片要素
1. 三个可爱的宠物角色（🐶🐰🐧）
2. 渐变背景（粉色-紫色-蓝色）
3. 中英文标题："PetPal - 智能情感桌面宠物"
4. 底部标注："XJTLU学生作品 | Alpha测试版"

### 功能展示图
1. 语言选择屏幕（国旗+文字）
2. 聊天界面（显示情绪检测）
3. 游戏截图（三个游戏拼图）
4. 心情追踪曲线图
5. 定制界面（多种宠物皮肤）

---

## 📊 推广渠道建议 / Promotion Channel Suggestions

### 中文平台
1. 小红书 - 重点推生活方式和治愈系内容
2. 微博 - 话题标签传播
3. B站 - 完整功能评测视频
4. 知乎 - 技术实现分析文章
5. 抖音 - 15秒功能快闪视频

### 英文平台
1. Twitter/X - Feature highlights
2. Product Hunt - Launch for feedback
3. GitHub - Open source community
4. Reddit - r/webdev, r/sideproject
5. LinkedIn - Academic innovation showcase

### 校园渠道
1. XJTLU官方社交媒体
2. 学生会公众号
3. 校园BBS/论坛
4. 学生创新创业展示平台
5. 校园开放日演示

---

## 🏷️ 关键词标签库 / Keyword Tags

### 中文标签
```
#PetPal #桌面宠物 #智能情感助手 #情绪陪伴 #情绪管理
#智能整理 #桌面助手 #AI聊天 #情绪检测 #心情追踪
#XJTLU #西交利物浦大学 #学生创新项目 #大学生创业
#开源项目 #Alpha测试 #治愈系应用 #心理健康
#迷你游戏 #情绪游戏 #解压神器 #暖心应用
#中英双语 #免费应用 #无广告 #隐私保护
```

### 英文标签
```
#PetPal #DesktopPet #EmotionalAI #CompanionApp #MoodTracking
#DesktopOrganizer #AIChat #EmotionDetection #MentalHealth
#XJTLU #StudentProject #OpenSource #AlphaVersion #InnovationProject
#MiniGames #EmotionalWellbeing #StressRelief #HealingApp
#Bilingual #FreeApp #NoAds #PrivacyFirst
```

---

## 📮 联系方式模板 / Contact Template

```
📧 反馈与建议：
欢迎通过应用内的反馈功能提交您的意见

🌐 项目信息：
开发团队：西交利物浦大学学生
项目性质：Alpha教育项目
用途说明：仅供学习和研究，非商业用途

⚠️ 免责声明：
本应用为学生创新项目，当前为Alpha测试版本，可能存在功能不完善或错误，仅供教育和研究目的使用。
```

---

*本文档持续更新中 | This document is continuously updated*
*最后更新：2025-11*
